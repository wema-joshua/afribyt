// auth_flow/onboardingScreen.dart
import 'package:flutter/material.dart';
import 'authscreen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with TickerProviderStateMixin {
  final PageController _controller = PageController();
  int _currentPage = 0;

  late AnimationController _imageAnimController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  final List<Map<String, String>> _pages = [
    {
      'image': 'assets/3D White People_ Handyman with a Toolbox Stock Illustration - Illustration of equipment, technician_ 31893160-Photoroom.png',
      'title': 'Welcome to Bytly!',
      'subtitle': 'We bring the service\nto your doorstep.',
    },
    {
      'image': 'assets/Ualá - Plenty Studio-Photoroom.png',
      'title': 'We are the Solution to your problem',
      'subtitle':
          'Find a technician to fix your issues\nat the comfort of your home',
    },
    {
      'image': 'assets/Smiling Cartoon Mechanic Holding Wrench And Tool Box, Box Clipart, Cartoon Clipart, Wrench Clipart PNG Transparent Image and Clipart for Free Download-Photoroom.png',
      'title': 'Access Anywhere',
      'subtitle':
          'Find, pay, and rate your technician\nfrom anywhere, anytime.',
    },
    {
      'image':
          'assets/Happy Labor Day! Cartoon Wrench Fix-It-Photoroom.png',
      'title': 'Bytly app',
      'subtitle': 'Make your life easier\n with the Bytly app',
    },
  ];

  @override
  void initState() {
    super.initState();

    // Animation controller for fade + zoom
    _imageAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );

    _fadeAnimation =
        Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(
      parent: _imageAnimController,
      curve: Curves.easeIn,
    ));

    _scaleAnimation =
        Tween<double>(begin: 0.8, end: 1.0).animate(CurvedAnimation(
      parent: _imageAnimController,
      curve: Curves.easeOutBack,
    ));

    // Start initial animation
    _imageAnimController.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    _imageAnimController.dispose();
    super.dispose();
  }

  void _animateImage() {
    _imageAnimController.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 36, 69, 253),
      body: SafeArea(
        child: Stack(
          children: [
            PageView.builder(
              controller: _controller,
              itemCount: _pages.length,
              onPageChanged: (idx) {
                setState(() => _currentPage = idx);
                _animateImage(); // Trigger animation on page change
              },
              itemBuilder: (context, idx) {
                final p = _pages[idx];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: TextButton(
                          onPressed: () {
                            _controller.animateToPage(
                              _pages.length - 1,
                              duration: const Duration(milliseconds: 300),
                              curve: Curves.easeInOut,
                            );
                          },
                          child: const Text('Skip',
                              style: TextStyle(color: Colors.white)),
                        ),
                      ),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            // ===========================
                            // ⭐ FADE + ZOOM IMAGE
                            // ===========================
                            FadeTransition(
                              opacity: _fadeAnimation,
                              child: ScaleTransition(
                                scale: _scaleAnimation,
                                child: Image.asset(
                                  p['image']!,
                                  fit: BoxFit.contain,
                                  height: 300,
                                ),
                              ),
                            ),

                            const SizedBox(height: 24),

                            Text(
                              p['title']!,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              p['subtitle']!,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 16),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),

            // ======================
            // DOT INDICATORS
            // ======================
            Positioned(
              bottom: 80,
              left: 0,
              right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(_pages.length, (i) {
                  final isActive = i == _currentPage;
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: isActive ? 12 : 8,
                    height: isActive ? 12 : 8,
                    decoration: BoxDecoration(
                      color: isActive ? Colors.white : Colors.white38,
                      shape: BoxShape.circle,
                    ),
                  );
                }),
              ),
            ),

            // ======================
            // NEXT / GET STARTED BUTTON
            // ======================
            Positioned(
              bottom: 24,
              right: 24,
              child: _currentPage == _pages.length - 1
                  ? ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        foregroundColor: const Color.fromARGB(255, 43, 75, 255),
                        backgroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 24, vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),

                      // GO TO AUTH SCREEN
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (_) => AuthScreen()),
                        );
                      },

                      child: const Text(
                        'Get Started',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                    )
                  : FloatingActionButton(
                      backgroundColor: Colors.white,
                      foregroundColor: const Color.fromARGB(255, 39, 71, 255),
                      onPressed: () => _controller.nextPage(
                        duration: const Duration(milliseconds: 800),
                        curve: Curves.easeInOut,
                      ),
                      child: const Icon(Icons.arrow_forward),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
